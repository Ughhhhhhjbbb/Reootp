#pragma once

// Pubgm India-64bit (3.4.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_FontColorPreset_type.BP_STRUCT_FontColorPreset_type
// 0x0020
struct FBP_STRUCT_FontColorPreset_type
{
	struct FString                                     ColorName_0_1C42E7C034F67EFF62F04ADD02C36995;             // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     FontColor_1_47C96D40797ED59D3F203D48062E8FC2;             // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

