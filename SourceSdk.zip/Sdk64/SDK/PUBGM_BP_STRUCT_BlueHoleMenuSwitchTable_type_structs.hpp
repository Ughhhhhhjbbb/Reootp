#pragma once

// Pubgm India-64bit (3.4.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_BlueHoleMenuSwitchTable_type.BP_STRUCT_BlueHoleMenuSwitchTable_type
// 0x0008
struct FBP_STRUCT_BlueHoleMenuSwitchTable_type
{
	int                                                ID_0_5F0348800013FD827BF3E8B40CF9CC34;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Open_1_4DF229C00107A107250A3BE209CD8A4E;                  // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

