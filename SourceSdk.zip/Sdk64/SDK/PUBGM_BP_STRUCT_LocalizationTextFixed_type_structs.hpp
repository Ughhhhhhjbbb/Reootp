#pragma once

// Pubgm India-64bit (3.4.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_LocalizationTextFixed_type.BP_STRUCT_LocalizationTextFixed_type
// 0x0150
struct FBP_STRUCT_LocalizationTextFixed_type
{
	struct FString                                     tr_0_2A65FE8050C91C9C71EC39C50EEE0B32;                    // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     zhTW_1_623C684021A0C9232B2A96630E0C8377;                  // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     fr_2_1821BB007577FA7E71ED46230EEE0A52;                    // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ja_3_542437C021D84D5171EC393D0EEE0B81;                    // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     id_4_2522584076C0389B71EC395B0EEE0A74;                    // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     vi_5_0866BCC026F9460571EC39880EEE0B49;                    // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     en_6_6918D9C04A5FE5C171ED460E0EEE0A3E;                    // 0x0060(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     zh_7_44793D80535998E871EC3B120EEE0C88;                    // 0x0070(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ru_8_4C5F3EC07A98F32D71EC3A1F0EEE0B15;                    // 0x0080(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     zhHK_9_2DF5E2400824FCAB2B2A94FC0E0C822B;                  // 0x0090(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     pt_10_6E547E002468C9BA71EC3A420EEE0BF4;                   // 0x00A0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ko_11_03371B804CF0621871EC38E70EEE0B9F;                   // 0x00B0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     es_12_691DDB004A5FE5C671ED46030EEE0A43;                   // 0x00C0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     th_13_2A5BFC0050C91C9271EC39CB0EEE0B28;                   // 0x00D0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     de_14_3A0AF7401F47D0FF71ED46F20EEE0A25;                   // 0x00E0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Key_15_4991AF400A82C50B0BCBD64F0EE09929;                  // 0x00F0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ar_16_2D0959C01DFF92E171ED45870EEE0A02;                   // 0x0100(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     hi_17_762279404BA823E771EC39470EEE0A69;                   // 0x0110(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ms_18_6144DD0023208B8E71EC38A90EEE0BC3;                   // 0x0120(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     uz_19_5972E0C07BE1315D71EC39BE0EEE0B4A;                   // 0x0130(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ur_20_596ADEC07BE1315571EC39A60EEE0B42;                   // 0x0140(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

