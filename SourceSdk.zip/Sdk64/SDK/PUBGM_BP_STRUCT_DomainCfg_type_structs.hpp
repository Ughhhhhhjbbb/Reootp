#pragma once

// Pubgm India-64bit (3.4.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_DomainCfg_type.BP_STRUCT_DomainCfg_type
// 0x0014
struct FBP_STRUCT_DomainCfg_type
{
	struct FString                                     Domain_0_6EFA5580518F51783205A5DB0670ACDE;                // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_023102C028A97AB12A1E4FB60A9B2624;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

