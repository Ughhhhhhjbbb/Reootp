#pragma once

// Pubgm India-64bit (3.4.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_DynamicLevels_type.BP_STRUCT_DynamicLevels_type
// 0x0019
struct FBP_STRUCT_DynamicLevels_type
{
	int                                                Id_0_44269CC0326607A73BAF3EE40E61EB64;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     Path_1_6A4DB4C04F0617316817D79501EAF6C8;                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               State_2_26DA11C0192873C12670ED910EA34EB5;                 // 0x0018(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

