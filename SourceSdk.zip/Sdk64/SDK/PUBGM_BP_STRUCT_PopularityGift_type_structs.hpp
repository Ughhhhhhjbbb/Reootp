#pragma once

// Pubgm India-64bit (3.4.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_PopularityGift_type.BP_STRUCT_PopularityGift_type
// 0x0134
struct FBP_STRUCT_PopularityGift_type
{
	int                                                PriceType_0_24103B8041D3955A0B649CBD0E5743F5;             // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                GiftId_1_73BCA4000296D1C2338B93AF099EC424;                // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     ItemName_2_59613A4022927A77049010190BBE9E75;              // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                MaxDevote_3_010F79803A776316095F91000D617135;             // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                popularity_4_1921AC8055DFC3503756D47508F2C7D9;            // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Price_5_59D79300427B069A65F244C90D839E55;                 // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                BuySourceDesc_6_3730DE401FD50DA952EEA7540546C7C3;         // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     GiftIcon_7_2E0B3B006006E856028E01AF0EC421CE;              // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                BuySource_8_5D9B9E801C60D17C2A65A1D30F6B5545;             // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FString                                     GiftAni_9_1D7E7EC00A06A55D4DDD4A4509EC4BD9;               // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ItemID_10_1BF0FD40544915C1152137F20A4BBD04;               // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                GiftOrder_11_158417C05BFE96417053B1B30C5B1322;            // 0x0054(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ExclusiveAccess_15_5D3278C01E70B03B6081AD3000888493;      // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                CanMessage_16_0D4E8C0034DEC4F80AD7A1180F134095;           // 0x005C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Intimacy_17_6D3A05C01AE226DF3CAB20BC04B4EE69;             // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0064(0x0004) MISSED OFFSET
	struct FString                                     GiftAni2_19_28DD2B40096B80A502FDD1260EC4BD52;             // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     GiftAni3_20_28DE2B80096B80A602FDD1210EC4BD53;             // 0x0078(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     DevoteCond_21_053431003393588E15686AF00A7089A4;           // 0x0088(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     LimitItemIDs_22_607C79C05925D95304D9BF820AC521D3;         // 0x0098(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Appid_23_359051C03647341320774BD90D9C6734;                // 0x00A8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                GiftType_24_50C28140353A206902E050D50EC579F5;             // 0x00B8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                EnableFollow_25_14C064C015F65605658F3D8103D15897;         // 0x00BC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                EnableFriend_26_1096DE007247191A621AAEF803DD9FB4;         // 0x00C0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x00C4(0x0004) MISSED OFFSET
	struct FString                                     VideoPath_27_4AF99740406C9DC56AD93B790B89E048;            // 0x00C8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     EffectIDs_28_59F5298012C058C82F783D3D0D771263;            // 0x00D8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     NoticeParam_29_76122B000FF3AEA4243876200407F34D;          // 0x00E8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                HornConfig_30_62E4518074304DF0196D61890E5DFB57;           // 0x00F8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               EnableSkip_32_47E5CDC03318778B6145801605F0A560;           // 0x00FC(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x3];                                       // 0x00FD(0x0003) MISSED OFFSET
	struct FString                                     EffectDesID_33_09A1D3C0541C837768BBF0BE07151AA4;          // 0x0100(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                pround_34_0C835C4013C9BC755222286A0A3A7894;               // 0x0110(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                GiftAudioID_35_674E38806B721D8C269C1A2805232F94;          // 0x0114(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               EnableExchange_36_701430C034E16A8F1C66DE800BFB9715;       // 0x0118(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x7];                                       // 0x0119(0x0007) MISSED OFFSET
	struct FString                                     HomeGiftEffectPath_37_6DFC11802F5AE78C17D17AE00DC4F168;   // 0x0120(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ManorVote_39_0C2B9D0075F8E3F00920034306AA71D5;            // 0x0130(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

