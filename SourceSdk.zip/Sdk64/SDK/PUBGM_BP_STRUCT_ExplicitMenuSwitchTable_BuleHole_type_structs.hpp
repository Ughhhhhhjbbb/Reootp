#pragma once

// Pubgm India-64bit (3.4.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_ExplicitMenuSwitchTable_BuleHole_type.BP_STRUCT_ExplicitMenuSwitchTable_BuleHole_type
// 0x000C
struct FBP_STRUCT_ExplicitMenuSwitchTable_BuleHole_type
{
	int                                                ID_0_79BBF0C004265AC77DAC2749037579A4;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MenuID_1_488136007386E6C02F28F4410A492CA4;                // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Open_2_4A1A920048095B047BF41863057A15CE;                  // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

