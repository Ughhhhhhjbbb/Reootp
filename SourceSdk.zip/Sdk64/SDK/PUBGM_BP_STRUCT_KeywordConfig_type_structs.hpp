#pragma once

// Pubgm India-64bit (3.4.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_KeywordConfig_type.BP_STRUCT_KeywordConfig_type
// 0x0018
struct FBP_STRUCT_KeywordConfig_type
{
	int                                                ID_0_401637806C8D86366542517508022A14;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     Keyword_1_679ACD80090BBBDA134C5AFD0D510434;               // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

