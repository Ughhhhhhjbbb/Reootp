#pragma once

// Pubgm India-64bit (3.4.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_VibrateAssetsConfig_type.BP_STRUCT_VibrateAssetsConfig_type
// 0x0144
struct FBP_STRUCT_VibrateAssetsConfig_type
{
	int                                                AssetID_0_059DEE4026286A2907474F0F0092C314;               // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     AssetRelativePath_1_5B725D403E5EC2B939CB33EE0286D2D8;     // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bOnlyMatchMainItemType_2_2645B4C02463FE5B6F1D510A0B0831C5;// 0x0018(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0019(0x0003) MISSED OFFSET
	float                                              PlayDuration_f_3_081DB3402719F2B7502265AF09936326;        // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                PlayPriority_4_37FCE90026FF13BC74D52C7B0517CE79;          // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	struct FString                                     PlayVibrateParam_5_1B9AA0003826534C3C3853ED04D4E1CD;      // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                TriggerEventType_6_0FF1C90073B75352744013220738F7E5;      // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	struct FString                                     TriggerMainItemData_7_4C6A8380560F226C1BECC4510C429DB1;   // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                TriggerMainItemType_8_16770D806B2D176C1BE579350C419575;   // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x4];                                       // 0x0054(0x0004) MISSED OFFSET
	struct FString                                     TriggerSubItem10Data_9_5BB58500035A6D9634F3E82001B8C4A1;  // 0x0058(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                TriggerSubItem10Type_10_25C20F002AAF67CE35CE870D01B9EC65; // 0x0068(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData05[0x4];                                       // 0x006C(0x0004) MISSED OFFSET
	struct FString                                     TriggerSubItem1Data_11_0A42B90069C5154659479BB8001A6E61;  // 0x0070(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                TriggerSubItem1Type_12_544F43007EE30A4659B68FF9001986A5;  // 0x0080(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData06[0x4];                                       // 0x0084(0x0004) MISSED OFFSET
	struct FString                                     TriggerSubItem2Data_13_0EB3394077AF9297589B562F00196E61;  // 0x0088(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                TriggerSubItem2Type_14_58BFC3400CCD8797589C7151001886A5;  // 0x0098(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData07[0x4];                                       // 0x009C(0x0004) MISSED OFFSET
	struct FString                                     TriggerSubItem3Data_15_1323B980059A0FE858D77AB200186E61;  // 0x00A0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                TriggerSubItem3Type_16_5D3043801AB804E85894D703001786A5;  // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData08[0x4];                                       // 0x00B4(0x0004) MISSED OFFSET
	struct FString                                     TriggerSubItem4Data_17_179439C013848D3958E39F1E00176E61;  // 0x00B8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                TriggerSubItem4Type_18_61A0C3C028A2823958FA5F62001686A5;  // 0x00C8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData09[0x4];                                       // 0x00CC(0x0004) MISSED OFFSET
	struct FString                                     TriggerSubItem5Data_19_1C04BA00216F0A8A5895642300166E61;  // 0x00D0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                TriggerSubItem5Type_20_66114400368CFF8A58EA048E001586A5;  // 0x00E0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData10[0x4];                                       // 0x00E4(0x0004) MISSED OFFSET
	struct FString                                     TriggerSubItem6Data_21_20753A402F5987DB58C14BDB00156E61;  // 0x00E8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                TriggerSubItem6Type_22_6A81C44044777CDB58DA64D9001486A5;  // 0x00F8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData11[0x4];                                       // 0x00FC(0x0004) MISSED OFFSET
	struct FString                                     TriggerSubItem7Data_23_24E5BA803D44052C58F5225600146E61;  // 0x0100(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                TriggerSubItem7Type_24_6EF244805261FA2C58C9E0D3001386A5;  // 0x0110(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData12[0x4];                                       // 0x0114(0x0004) MISSED OFFSET
	struct FString                                     TriggerSubItem8Data_25_29563AC04B2E827D5F0FF5C200136E61;  // 0x0118(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                TriggerSubItem8Type_26_7362C4C0604C777D5F79E52E001286A5;  // 0x0128(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData13[0x4];                                       // 0x012C(0x0004) MISSED OFFSET
	struct FString                                     TriggerSubItem9Data_27_2DC6BB005918FFCE58D56F7700126E61;  // 0x0130(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                TriggerSubItem9Type_28_77D345006E36F4CE5F0931D6001186A5;  // 0x0140(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

