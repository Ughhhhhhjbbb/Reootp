#pragma once

// Pubgm India-64bit (3.4.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_EffectItemBPTable_type.BP_STRUCT_EffectItemBPTable_type
// 0x0038
struct FBP_STRUCT_EffectItemBPTable_type
{
	struct FString                                     CName_0_7A84EC0050230586473C7F7D0FE10665;                 // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_77819E4026AAFDFB236ABAEE0425FEA4;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     LobbyPath_2_667FDC4028D32C79798D4B120AC19EB8;             // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Path_3_084F3E402A58FF7D0D305BF205FF1C88;                  // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

