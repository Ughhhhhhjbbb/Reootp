// Pubgm India-64bit (3.4.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

#include "../SDK.hpp"

namespace SDK
{
//---------------------By BangJO---------------------------
//Functions
//---------------------By BangJO---------------------------

// Function Editor_login.Editor_login_C.SetFpsByIndex
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// int                            idx                            (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void AEditor_login_C::SetFpsByIndex(int idx)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Editor_login.Editor_login_C.SetFpsByIndex");

	AEditor_login_C_SetFpsByIndex_Params params;
	params.idx = idx;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Editor_login.Editor_login_C.InpActEvt_Android_Back_K2Node_InputKeyEvent_10
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm)

void AEditor_login_C::InpActEvt_Android_Back_K2Node_InputKeyEvent_10(const struct FKey& Key)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Editor_login.Editor_login_C.InpActEvt_Android_Back_K2Node_InputKeyEvent_10");

	AEditor_login_C_InpActEvt_Android_Back_K2Node_InputKeyEvent_10_Params params;
	params.Key = Key;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Editor_login.Editor_login_C.InpActEvt_E_K2Node_InputKeyEvent_9
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm)

void AEditor_login_C::InpActEvt_E_K2Node_InputKeyEvent_9(const struct FKey& Key)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Editor_login.Editor_login_C.InpActEvt_E_K2Node_InputKeyEvent_9");

	AEditor_login_C_InpActEvt_E_K2Node_InputKeyEvent_9_Params params;
	params.Key = Key;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Editor_login.Editor_login_C.InpActEvt_BackSpace_K2Node_InputKeyEvent_8
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm)

void AEditor_login_C::InpActEvt_BackSpace_K2Node_InputKeyEvent_8(const struct FKey& Key)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Editor_login.Editor_login_C.InpActEvt_BackSpace_K2Node_InputKeyEvent_8");

	AEditor_login_C_InpActEvt_BackSpace_K2Node_InputKeyEvent_8_Params params;
	params.Key = Key;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Editor_login.Editor_login_C.InpActEvt_B_K2Node_InputKeyEvent_7
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm)

void AEditor_login_C::InpActEvt_B_K2Node_InputKeyEvent_7(const struct FKey& Key)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Editor_login.Editor_login_C.InpActEvt_B_K2Node_InputKeyEvent_7");

	AEditor_login_C_InpActEvt_B_K2Node_InputKeyEvent_7_Params params;
	params.Key = Key;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Editor_login.Editor_login_C.InpActEvt_G_K2Node_InputKeyEvent_6
// (BlueprintEvent)
// Parameters:
// struct FKey                    Key                            (BlueprintVisible, BlueprintReadOnly, Parm)

void AEditor_login_C::InpActEvt_G_K2Node_InputKeyEvent_6(const struct FKey& Key)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Editor_login.Editor_login_C.InpActEvt_G_K2Node_InputKeyEvent_6");

	AEditor_login_C_InpActEvt_G_K2Node_InputKeyEvent_6_Params params;
	params.Key = Key;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Editor_login.Editor_login_C.ReceiveBeginPlay
// (Event, Protected, BlueprintEvent)

void AEditor_login_C::ReceiveBeginPlay()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Editor_login.Editor_login_C.ReceiveBeginPlay");

	AEditor_login_C_ReceiveBeginPlay_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Editor_login.Editor_login_C.ExecuteUbergraph_Editor_login
// (HasDefaults)
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void AEditor_login_C::ExecuteUbergraph_Editor_login(int EntryPoint)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Editor_login.Editor_login_C.ExecuteUbergraph_Editor_login");

	AEditor_login_C_ExecuteUbergraph_Editor_login_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


}

