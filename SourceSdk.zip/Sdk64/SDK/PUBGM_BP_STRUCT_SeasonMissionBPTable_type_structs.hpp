#pragma once

// Pubgm India-64bit (3.4.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_SeasonMissionBPTable_type.BP_STRUCT_SeasonMissionBPTable_type
// 0x0038
struct FBP_STRUCT_SeasonMissionBPTable_type
{
	struct FString                                     CName_0_3B02C7C021A8868F32F1BA220D295515;                 // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_73B51A0066811C521281291A0132D224;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     Path_2_746EFA0071EA42DC1C74470F02D39998;                  // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Wrapper_3_324A4F00599DC022161C6E8C019B5BF2;               // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

