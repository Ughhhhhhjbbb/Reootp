#pragma once

// Pubgm India-64bit (3.4.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_StatEvent_BH_type.BP_STRUCT_StatEvent_BH_type
// 0x0025
struct FBP_STRUCT_StatEvent_BH_type
{
	struct FString                                     adjustAndroidToken_0_3260FA803AA461963779D9DB0E92099E;    // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     adjustIOSToken_1_095B450060997F920AB32CC30A9631DE;        // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                id_2_5EE97A802C29D48434A3CC2A0703D804;                    // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               unique_3_33982D001023CDFA58CAB38B09540B65;                // 0x0024(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

