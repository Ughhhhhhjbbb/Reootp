#pragma once

// Pubgm India-64bit (3.4.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_LocalizationTextFixed_BLUEHOLE_type.BP_STRUCT_LocalizationTextFixed_BLUEHOLE_type
// 0x0150
struct FBP_STRUCT_LocalizationTextFixed_BLUEHOLE_type
{
	struct FString                                     ar_0_541F05803F79F84A531D33090C1980F2;                    // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     de_1_6120A30064A0E73A531D31940C1980D5;                    // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     en_2_102E858046588C42531D31FE0C1980CE;                    // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     es_3_103386C046588C47531D31830C1980B3;                    // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     fr_4_3F3766C028103145531D30E40C1980A2;                    // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     hi_5_1D3825006B7F7B3A531D301F0C198099;                    // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     id_6_4C3804004D372034531D30710C198084;                    // 0x0060(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ja_7_7B39E3802EEEC530531D39640C198171;                    // 0x0070(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Key_8_490D7B0074C5F6242B7093E001983609;                   // 0x0080(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ko_9_2A4CC74010A66A3D531D39770C19816F;                    // 0x0090(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ms_10_085A88C05415B43F531D36A90C198133;                   // 0x00A0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     pt_11_156A29C0793CA33D531D390E0C198104;                   // 0x00B0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ru_12_7374EA803CABED3C531D36420C1981E5;                   // 0x00C0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     th_13_5171A7C0001B372D531D37950C1981D8;                   // 0x00D0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     tr_14_517BAA40001B3737531D379F0C1981C2;                   // 0x00E0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     vi_15_2F7C6880438A812C531D36D10C1981B9;                   // 0x00F0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     zh_16_6B8EE9404A691527531D37490C198278;                   // 0x0100(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     zhHK_17_74C7CE003DBEA934524FCEB4098270DB;                 // 0x0110(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     zhTW_18_290E54001C481374524FC23509827187;                 // 0x0120(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     uz_19_00888C8061D2DC3E531D37A60C1981BA;                   // 0x0130(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ur_20_00808A8061D2DC36531D37BE0C1981B2;                   // 0x0140(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

