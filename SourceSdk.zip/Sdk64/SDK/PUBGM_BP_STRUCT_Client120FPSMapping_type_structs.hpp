#pragma once

// Pubgm India-64bit (3.4.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_Client120FPSMapping_type.BP_STRUCT_Client120FPSMapping_type
// 0x0028
struct FBP_STRUCT_Client120FPSMapping_type
{
	int                                                ID_0_52B7B2807016C5CE506644460AB41F74;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     ModelNames_1_399D08807AD6F26037FD5FE60034ECE3;            // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     RecommendFPS_2_1A6DF000025FF64C17E158AF0DA5B963;          // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

