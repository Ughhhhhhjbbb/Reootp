#pragma once

// Pubgm India-64bit (3.4.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_FontStylePreset_type.BP_STRUCT_FontStylePreset_type
// 0x0020
struct FBP_STRUCT_FontStylePreset_type
{
	struct FString                                     FontName_0_44EF324019A535D53F56006B0E9E4B85;              // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     FontPath_1_008D9540303E41453F57D0D90E9C6518;              // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

