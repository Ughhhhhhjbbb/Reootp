#pragma once

// Pubgm India-64bit (3.4.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_TransSupportConfig_BLUEHOLE_type.BP_STRUCT_TransSupportConfig_BLUEHOLE_type
// 0x003C
struct FBP_STRUCT_TransSupportConfig_BLUEHOLE_type
{
	struct FString                                     abbreviation_0_576485800BFD34B24C1B5171096239DE;          // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     displayName_1_34DEC5C0314832596E20702806D96E95;           // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               isSupported_2_633B50801434DC72755E836C03183084;           // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
	struct FString                                     languageCode_3_715457C04402C35F3D3E137D011FE455;          // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                languageID_4_4A0F5C4033CF49852F4DA25701F11F94;            // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

